package com

class Properties {
}


