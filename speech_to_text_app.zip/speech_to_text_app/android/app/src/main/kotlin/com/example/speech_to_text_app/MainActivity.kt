package com.example.speech_to_text_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
