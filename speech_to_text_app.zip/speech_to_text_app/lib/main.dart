import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:camera/camera.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ดึงรายการกล้องที่ใช้งานได้
  List<CameraDescription> cameras = await availableCameras();
  runApp(MyApp(cameras: cameras));
}

class MyApp extends StatelessWidget {
  final List<CameraDescription> cameras; // ประกาศตัวแปร cameras

  const MyApp({Key? key, required this.cameras}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Camera Example',
      initialRoute: '/',
      routes: {
        '/': (context) => SpeechToTextScreen(),
        '/camera': (context) => CameraScreen(camera: cameras.first), // ส่ง camera ไปยัง CameraScreen
        '/drug': (context) => drug(),
        '/hello': (context) => hello(),
        '/TakeMedicineWhenWeGetSymptoms': (context) => TakeMedicineWhenWeGetSymptoms(),
        '/eat': (context) => eat(),
      },
    );
  }
}

class SpeechToTextScreen extends StatefulWidget {
  @override
  _SpeechToTextScreenState createState() => _SpeechToTextScreenState();
}

class _SpeechToTextScreenState extends State<SpeechToTextScreen> {
  late stt.SpeechToText _speech;
  late Timer _timer;
  bool _isListening = false;
  String _text = 'กดปุ่มเพื่อเริ่มพูด';
  bool _isSpeaking = false; // เพิ่มตัวแปรเพื่อตรวจสอบว่ามีเสียงพูดหรือไม่

void _startListening() {
  _speech.listen(
    onResult: (result) {
      setState(() {
        _text = result.recognizedWords;
        _isSpeaking = result.finalResult; // finalResult เป็น true เมื่อพูดเสร็จแล้ว
      });
      _processText(result.recognizedWords);
      if (!_isSpeaking) {
        _startTimeout(); // เริ่มจับเวลาเมื่อไม่มีเสียง
      } else {
        _timer.cancel(); // ยกเลิกจับเวลาเมื่อมีเสียงพูด
      }
    },
    localeId: 'th-TH',
  );

  if (!_isSpeaking) {
    _startTimeout(); // เริ่มจับเวลาเมื่อไม่มีเสียง
  } else {
    _timer.cancel(); // ยกเลิกจับเวลาเมื่อมีเสียงพูด
  }
}


  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _initializeSpeechRecognizer();
  }

void _startTimeout() {
  const int timeoutMilliseconds = 12000;
  _timer = Timer(Duration(milliseconds: timeoutMilliseconds), () {
    // ถ้ายังไม่มีการจดจำภาษาอยู่เมื่อเริ่มต้น
    if (!_isSpeaking) {
      setState(() {
        _text = 'ไม่มีเสียง';
      });
      _speech.stop();
    }
  });
}


@override
void dispose() {
  _speech.stop();
  _timer.cancel(); // ยกเลิกการจับเวลาเมื่อทำการ dispose
  super.dispose();
}

void _initializeSpeechRecognizer() async {
  bool isAvailable = await _speech.initialize(
    onStatus: (status) {
      print('สถานะการจดจำภาษา: $status');
      if (status == 'listening') {
        setState(() {
          _isListening = true;
          _startTimeout();
        });
      } else if (status == 'notListening') {
        setState(() {
          _isListening = false;
        });
        _speech.stop();
        _timer.cancel(); // ยกเลิกการจับเวลาเมื่อหยุดการจดจำภาษา
      }
    },
    onError: (errorNotification) {
      print('ข้อผิดพลาดในการจดจำภาษา: $errorNotification');
      setState(() {
        _isListening = false;
      });
      _speech.stop();
      _timer.cancel(); // ยกเลิกการจับเวลาเมื่อเกิดข้อผิดพลาด
    },
  );

  if (!isAvailable) {
    print('ไม่สามารถใช้การจดจำภาษาได้');
  }
}

  void _stopListening() {
    _speech.stop();
    setState(() => _isListening = false);
  }

  void _processText(String text) {
    print('ข้อความที่ได้: $text');
    if (text == 'ยา') {
      Navigator.pushNamed(context, '/drug');
    }
    else if (text == 'สวัสดี') {
      Navigator.pushNamed(context, '/hello');
    }
    else if (text == 'ทานยาเมื่อมีอาการ') {
      Navigator.pushNamed(context, '/TakeMedicineWhenWeGetSymptoms');
    }
    else if (text == 'กิน') {
      Navigator.pushNamed(context, '/eat');
    }
   
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('บันทึกเสียงเพื่อแปลภาษา'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _text,
              style: TextStyle(fontSize: 24.0),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20.0),
            _isListening
                ? ElevatedButton(
                    onPressed: _stopListening,
                    child: Text('หยุดการบันทึกเสียง'),
                  )
                : ElevatedButton(
                    onPressed: _startListening,
                    child: Text('เริ่มการบันทึกเสียง'),
                  ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/camera');
              },
              child: Text('เปิดกล้องเพื่ออ่านภาษามือ'),
            ),
          ],
        ),
      ),
    );
  }
}

class VideoPlayerScreen extends StatefulWidget {
  final File videoFile;

  VideoPlayerScreen({required this.videoFile});

  @override
  _VideoPlayerScreenState createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late VideoPlayerController _controller;
  late Future<void> _initializeVideoPlayerFuture;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.videoFile);
    _initializeVideoPlayerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('เล่นวิดีโอ'),
      ),
      body: FutureBuilder(
        future: _initializeVideoPlayerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return AspectRatio(
              aspectRatio: _controller.value.aspectRatio,
              child: VideoPlayer(_controller),
            );
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            if (_controller.value.isPlaying) {
              _controller.pause();
            } else {
              _controller.play();
            }
          });
        },
        child: Icon(
          _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
        ),
      ),
    );
  }
}

class drug extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return VideoPlayerScreen(
      videoFile: File("D:\ยา.mp4"), // แทนที่ด้วยพาธไปยังไฟล์วิดีโอจริง
    );
  }
}

class hello extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return VideoPlayerScreen(
      videoFile: File("D:\สวัสดี.mp4"), // แทนที่ด้วยพาธไปยังไฟล์วิดีโอจริง
    );
  }
}

class TakeMedicineWhenWeGetSymptoms extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return VideoPlayerScreen(
      videoFile: File("D:\ทานยาเมื่อมีอาการ.mp4"),
    );
  }
}

class eat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return VideoPlayerScreen(
      videoFile: File("D:\กิน.mp4"),
    );
  }
}

class TtsPage extends StatefulWidget { //texttospeech
  @override
  _TtsPageState createState() => _TtsPageState();
}

class _TtsPageState extends State<TtsPage> {
  FlutterTts flutterTts = FlutterTts();

  @override
  void initState() {
    super.initState();
    // ตั้งค่า TTS
    flutterTts.setLanguage("th-TH"); // ตั้งค่าภาษาเป็น "th-TH" สำหรับภาษาไทย
    flutterTts.setPitch(1.0); // ตั้งค่าระดับเสียงพิตช์ (1.0 เป็นค่าเริ่มต้น)
  }

  // ฟังก์ชันในการพูดข้อความ
  Future<void> speak(String text) async {
    await flutterTts.awaitSpeakCompletion(true); // รอให้การพูดเสร็จสิ้นก่อนทำงานต่อ
    await flutterTts.speak(text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Text-to-Speech (ภาษาไทย)"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            ElevatedButton(
              onPressed: () {
                speak("สวัสดีครับ ยินดีที่ได้พบคุณ"); // ตัวอย่างข้อความภาษาไทยที่ต้องการให้ TTS พูด
              },
              child: Text("พูด"),
            ),
          ],
        ),
      ),
    );
  }
}

class CameraScreen extends StatefulWidget {
  final CameraDescription camera;

  const CameraScreen({Key? key, required this.camera}) : super(key: key);

  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;

  @override
  void initState() {
    super.initState();
    // สร้าง Controller สำหรับกล้อง
    _controller = CameraController(
      widget.camera,
      ResolutionPreset.medium,
    );

    // Initialize the controller. Returns a Future.
    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    // ปลดที่จอแสดงภาพ
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Camera Example')),
      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            // แสดงกล้องเมื่อเรียบร้อยแล้ว
            return CameraPreview(_controller);
          } else {
            // แสดง Progress indicator ขณะที่กำลังเตรียมกล้อง
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}